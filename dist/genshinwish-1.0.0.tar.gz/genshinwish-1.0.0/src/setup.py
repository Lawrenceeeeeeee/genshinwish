import setuptools


setuptools.setup(
    name="src",
    version="1.0",
    author="Lawrence Guo",
    author_email="775569157@qq.com",
    description="",
    long_description="src",
    long_description_content_type="src",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
